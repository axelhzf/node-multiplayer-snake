(function () {
    "use strict";

    Game.BoardView = Backbone.View.extend({

    });

}());