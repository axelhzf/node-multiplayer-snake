(function () {
    "use strict";

    Game.PlayersView = Backbone.View.extend({

    });

}());